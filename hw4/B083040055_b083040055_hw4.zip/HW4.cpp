#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>
#include <ctime>
#include <time.h>

using namespace std;

#define n4 1000			 
#define alpha 0.9		

int calValue(int a[1000],int value[1000],int n) 
{		
	int i=0,val=0;
	for(i=0;i<n;i++)
	{
		val+=a[i]*value[i];
	}
	return val;
}

int calWeight(int a[1000],int weight[1000],int n) 
{		
	int i=0,w=0;
	for(i=0;i<n;i++)
	{
		w+=a[i]*weight[i];
	}
	return w;
}

double generateDoubleRandomNumber()						
{
	return((double)rand()/((double)(RAND_MAX)+1.0)); 
}

void randomval(int a[1000],int weight[1000],int capacity,int n) 
{																
	int r1=0,r2=0;
	while(r1==r2) 
	{
		r1=rand()%n;
		r2=rand()%n;
	}												 
	
	a[r1]=1;
	a[r2]=1;
	
	if(calWeight(a,weight,n)>capacity)
	{															
		a[r1]=0;
	}															
	if(calWeight(a,weight,n)>capacity)
	{														
		a[r2]=0;
	}
}

int aa(int size,int weight[1000],int value[1000],int flag[1000],int n) 
{			
	int tempValue=0,bestValue=0;							
	int a[1000],temp[1000],best[1000];	
	double T;									
	int i=0,j=0;
	int diff1=0,diff2=0;						
	double p=0.0;											
	for(int i=0;i<1000;i++)
	{
		a[i]=0;
		temp[i]=0;
		best[i]=0;
	}
	T=size;
	//Initialization	
	for(i=0;i<n4;i++) 
	{
		a[i]=0;
		temp[i]=0;
		best[i]=0;
	}
	tempValue=calValue(a,value,n);
	bestValue=tempValue;
	
	while(T>1)												
	{
		for(i=0;i<2500;i++)											
		{														
			randomval(a,weight,size,n);							
			diff1=calValue(a,value,n)-bestValue;			
			if(diff1>0) 
			{								
				for(j=0;j<n;j++) 
				{						
					best[j]=a[j];
				}
				tempValue=calValue(a,value,n);
				bestValue=tempValue;
			}
			else 
			{
				diff2=calValue(a,value,n)-tempValue;		
				if(diff2>0) 
				{								
					for(j=0;j<n;j++)
					{							
						temp[j]=a[j];
					}
					tempValue=calValue(a,value,n);
				}
				else 
				{
					p=generateDoubleRandomNumber();				
					if(exp((diff2)/T)>p) 
					{				
						for(j=0;j<n;j++)
						{					
							temp[j]=a[j];
						}
						tempValue=calValue(a,value,n);
					}
					else 
					{											
						for(j=0;j<n;j++)
						{					
							a[j]=temp[j];
						}
					}
				}
			}
		}
		T=T*alpha;													
	}
	for(i=0;i<n;i++)
	{
		flag[i]=best[i];	
	}
	return bestValue;
}

int main() 
{
	ifstream file1;
	int size,i,bestValue;							
	int weight[1000],value[1000],flag[1000];
	srand(time(NULL));
	
	for(int i=0;i<1000;i++)
	{
		weight[i]=0;
		value[i]=0;
		flag[i]=0;
	}
   	string name;
	cout<<"Input the file name. ";
	cin>>name;
	
	file1.open("c.txt");
	if(file1.is_open())
	{
		while(!file1.eof())
		{
			file1>>size;
		}
	}
	file1.close();
	int j2=0;
	file1.open("w.txt");
	if(file1.is_open())
	{
		j2=0;
		while(!file1.eof())
		{
			file1>>weight[j2];
			j2++;	
		}
	}
	file1.close();
	if(j2==31)
	{
		j2=j2-1;
	}
	else if(j2==1001)
	{
		j2=j2-1;
	}
	file1.open("p.txt");
	int m=0;
	if(file1.is_open())
	{
		m=0;
		while(!file1.eof())
		{
			file1>>value[m];
			m++;
		}
	}
	file1.close();
						
	bestValue=aa(size,weight,value,flag,j2);
	
	ofstream fout(name.c_str());
	fout<<bestValue<<endl;
	for(i=0;i<j2;i++) 
	{
		fout<<flag[i]<<endl;
	}
	fout.close();
    return 0;
}
