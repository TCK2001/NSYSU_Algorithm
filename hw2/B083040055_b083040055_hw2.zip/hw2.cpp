#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>

/*
5 26
[12] 24 [7] 13 [11] 23 [8] 15 [9] 16

5 26
12 24 7 13 11 23 8 15 9 16

10 165
23 92 31 57 29 49 44 68 53 60 38 43 63 67 85 84 89 87 82 72

29 538350
37278 8237 13768 5355 43947 7049 54276 2298 44203 1657 92216 5703 53482 1008 28993 6067 78125 5895 53882 3353 66418 7425
85067 6987 6848 3189 20494 9245 16294 7575 43480 5536 32622 3014 81597 4031 15054 1202 28899 9514 9530 95 32424 5711
98819 6790 64021 6536 3041 8042 5937 1371 63318 7415 49974 4112 36041 7964
*/ 

using namespace std;

double W[100]={0};
double P[100]={0};
int check[100]={0};
double save[100]={0};
double subsaveW[100]={0};
double subsaveP[100]={0};
double sub=0;
int N,K;
int j=0; //w ���Ͽ� ����;
int k=0; //p ���Ͽ� ����; 
double MaxP=0;

int main()
{
	string name;
	cout<<"Input the file name."<<endl;
	cin>>name;
	fstream file11;
	file11.open("c.txt");
	if(file11.is_open())
	{
		while(!file11.eof())
		{
			file11>>K;
		}
	}
	file11.close();
	cout<<K<<endl;
	
	ifstream file22;
	file22.open("w.txt");
	if(file22.is_open())
	{
		j=0;
		while(!file22.eof())
		{
			file22>>W[j];
			j++;	
		}
	}
	file22.close();
	for(int ww=0;ww<j;ww++)
	{
		cout<<W[ww]<<" ";
		N++;
	}
	cout<<N<<endl;	
	
	ifstream file33;
	file33.open("p.txt");
	if(file33.is_open())
	{
		k=0;
		while(!file33.eof())
		{
			file33>>P[k];
			k++;
		}
	}
	file33.close();
	for(int pp=0;pp<k;pp++)
	{
		cout<<P[pp]<<" ";
	}
	cout<<endl;
	
	/*cin>>N>>K;
	for(int i=0;i<N;i++)
	{
		cin>>W[i]>>P[i];
	}
	*/
	
	for(int i=0;i<N;i++)
	{
		subsaveW[i]=W[i];
		subsaveP[i]=P[i];	
	}
	for(int j=0;j<N;j++)
	{
		save[j]=P[j]/W[j];
	}
	cout<<fixed;
	cout<<setprecision(2);
	for(int i=0;i<N;i++)
	{
		for(int j=i;j<N;j++)
		{
			if(save[i]>save[j])
			{
				double temp1;
				temp1=save[i];
				save[i]=save[j];
				save[j]=temp1;
				
				int temp2;
				temp2=W[i];
				W[i]=W[j];
				W[j]=temp2;
				
				int temp3;
				temp3=P[i];
				P[i]=P[j];
				P[j]=temp3;
				
				int temp4;
				temp4=check[i];
				check[i]=check[j];
				check[j]=temp4;
			}
		}
	}
	for(int j=0;j<N;j++)
	{
		cout<<"Changed : "<<j+1<<" Case : "<<save[j]<<" Weight: "<<W[j]<<" Value: "<<P[j]<<endl;
	}
	//�ʱ�ȭ; 
	for(int k=0;k<N;k++)
	{
		check[k]=0;
	}
	//������ �� ū�� ���ϱ� �׸��� ����;
	sub=sub+W[N-1]; 
	MaxP=MaxP+P[N-1];
	cout<<"First P is :"<<MaxP<<endl;
	for(int h=0;h<N;h++)
	{
		if(sub==subsaveW[h])
		{
			check[h]=1;
			cout<<"Hi check is "<<check[h]<<endl;
		}
	}
	cout<<"First sub is :"<<sub<<endl;
	for(int k=0;k<N;k++)
	{
		cout<<check[k]<<" ";
	}
	cout<<endl;
	//check�˻� �غ���;
	
	int subN=N;
	for(int i=subN-2;i>=0;i--)
	{
		for(int j=subN-3;j>=0;j--)
		{
			if(sub+W[j]<=K)
			{
				MaxP=MaxP+P[j];
				cout<<"Now add num is "<<W[j]<<endl;
				//check[j]=1; 
				cout<<"Now check is "<<check[j]<<endl;
				for(int h=0;h<N;h++)
				{
					if(W[j]==subsaveW[h])
					{
						check[h]=1;
					}
					cout<<check[h]<<" ";
				}
				cout<<endl;
				sub+=W[j];
				cout<<"Now thw weight is sub: "<<sub<<endl;
			}
			else if(sub+W[j]>K)
			{
				break;
			}
		}
	}
	for(int k=0;k<N;k++)
	{
		cout<<check[k]<<" ";
	}
	cout<<endl;
	cout<<"Max P is : "<<MaxP<<endl; 
	ofstream fout(name.c_str());
	fout<<MaxP<<endl;
	for(int k=0;k<N;k++)
	{
		fout<<check[k]<<endl;
	}
	cout<<endl;
return 0;
}

