#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#include <fstream>
#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>
#include <cmath>
#include <time.h>
#include <ctime>
/*
5 26
[12] 24 [7] 13 [11] 23 [8] 15 [9] 16

5 26
12 24 7 13 11 23 8 15 9 16

10 165
23 92 31 57 29 49 44 68 53 60 38 43 63 67 85 84 89 87 82 72

29 538350
37278 8237 13768 5355 43947 7049 54276 2298 44203 1657 92216 5703 53482 1008 28993 6067 78125 5895 53882 3353 66418 7425
85067 6987 6848 3189 20494 9245 16294 7575 43480 5536 32622 3014 81597 4031 15054 1202 28899 9514 9530 95 32424 5711
98819 6790 64021 6536 3041 8042 5937 1371 63318 7415 49974 4112 36041 7964
*/

using namespace std;

double W[100]={0};
double P[100]={0};
int check[100]={0};
int subcheck[100]={0};
double saveW=0;
double saveP=0;
double MaxW;
double MaxP;
int N=0,K=0;
int j=0; //w ���Ͽ� ����;
int k=0; //p ���Ͽ� ����; 
int i=0;




void aa(int K,string name,int N)
{
	clock_t timeStart = clock();
	for(i=0;i<pow(2,N);i++) 
	{
		j=N-1;
		saveW=0;
		saveP=0; 
		while(check[j]!=0&&j>=0) 
		{
			check[j]=0;
			j-=1;
		}
		check[j]=1;
		/*cout<<"Now check is : "<<endl;
		for(int i=0;i<N;i++)
		{
			cout<<check[i]<<" ";
		}*/
		cout<<endl;
		for(k=0;k<N;k++) 
		{
			if(check[k]==1) 
			{
				saveW+=W[k];
				saveP+=P[k];
			}
		}
		if((saveP>=MaxP)&&(saveW<=K)) 
		{
			MaxP=saveP;
			MaxW=saveW;
			for(k=0;k<N;k++)
			{
				subcheck[k]=check[k];	
			}
		}
		if((clock()-timeStart)/CLOCKS_PER_SEC>=60) 
		{
			ofstream fout(name.c_str());
			fout<<MaxP<<endl;
			for(int k=0;k<N;k++)
			{
				fout<<subcheck[k]<<endl;
			}
			cout<<endl;
			break;	
        }
	}
	///////////
	
}




int main()
{
	/*FILE *fp;
	string filename;
	getline(cin, filename, '\n');
	ifstream fp(filename.c_str(), ios::out);
	//fp=fopen("C:\Users\��°�\Desktop\���� 1~2\b083040055_hw1\ds\c.txt")
	if(fp==NULL)
	{
		cout<<"ERROR"<<endl;
	}
	fclose(fp);
	cout<<"Finish"<<endl;
	*/
	string name;
	cout<<"Input the file name."<<endl;
	cin>>name;
	ifstream file1;
	file1.open("c.txt");
	if(file1.is_open())
	{
		while(!file1.eof())
		{
			file1>>K;
		}
	}
	file1.close();
	cout<<K<<endl;
	
	ifstream file2;
	file2.open("w.txt");
	if(file2.is_open())
	{
		j=0;
		while(!file2.eof())
		{
			file2>>W[j];
			j++;	
		}
	}
	file2.close();
	for(int ww=0;ww<j;ww++)
	{
		cout<<W[ww]<<" ";
		N++;
	}
	if(N==31)
	{
		N=N-1;
	}
	cout<<N<<endl;	
	
	ifstream file3;
	file3.open("p.txt");
	if(file3.is_open())
	{
		k=0;
		while(!file3.eof())
		{
			file3>>P[k];
			k++;
		}
	}
	file3.close();
	for(int pp=0;pp<k;pp++)
	{
		cout<<P[pp]<<" ";
	}

	/*cin>>N>>K;
	for(int i=0;i<N;i++)
	{
		cin>>W[i]>>P[i];
	}*/
	aa(K,name,N);
	
return 0;
}

