#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <vector>
#include <fstream>
#include <stdio.h> 
#include <conio.h>
#include <stdlib.h>

/*5 26
12 24 7 13 11 23 8 15 9 16*/

using namespace std;

int w[1001]; // ����
int v[1001]; // ��ġ
int N2,K2; // ��ǰ�� �� N, �ؼ��� ��ƿ �� �ִ� ���� K
int subK;
int j2,m;
int subW[1001];
int subV[1001];
void aa(int N,string name,int K)
{
	//cin>>N>>K;
	subK=K;
	int **dp;
	dp=new int*[N+1];
	for(int i=0;i<=N;i++)
	{
		dp[i]=new int[K+1];
	}
	for(int i=0;i<=K;i++)
	{
		dp[0][i]=0;
	}
	for(int j=0;j<=N;j++)
	{
		dp[j][0]=0;
	}
//	for(int i=1;i<=N;i++) 
//	{
//		cin>>w[i]>>v[i];
//	}
    //���Զ� �� �Է� �Լ� 
	
	for(int m=0;m<N;m++)
	{
		subW[m+1]=w[m];
	}
	
	for(int n=0;n<N;n++)
	{
		subV[n+1]=v[n];
	}
/*	
	for(int m=1;m<=N;m++)
	{
		cout<<subW[m]<<" ";
	}
	cout<<endl;
	
	for(int n=1;n<=N;n++)
	{
		cout<<subV[n]<<" ";
	}
	cout<<endl;*/
	for(int i=1;i<=N;i++) 
	{	
		for(int j=1;j<=K;j++) 
		{	
			if(j-subW[i]>=0) 
			{ // i��° ������ ���� �� �ִٸ�?
				
				dp[i][j]=max(dp[i-1][j],dp[i-1][j-subW[i]]+subV[i]);
                // ���� ���� ���� �־��� ��, �� �� �� ū ������ �ʱ�ȭ
			}
            else
			{ // i��° ������ ���� �� ���ٸ�, �賶 �뷮�� ���� ���� �ʾ��� ���� ������ �ʱ�ȭ
                dp[i][j]=dp[i-1][j];
            }
		}	
	}
	
	int check[N+1];
	for(int k=1;k<=N;k++)
	{
		check[k]=0;
	}
	
	for(int i=N;i>=1;i--)
	{
		if(dp[i][K]>dp[i-1][K])
		{
			K=K-subW[i];
			check[i]=1;
		}
		else
		{
			check[i]=0;
		}
	}
	//cout<<"ss"<< subK<<endl;
	ofstream fout(name.c_str());
	fout<<dp[N][subK]<<endl;
	for(int k=1;k<=N;k++)
	{
		fout<<check[k]<<endl;
	}
	cout<<endl;
	
	for(int j=0;j<=N;j++)
	{
		delete []dp[j];
	}
	delete []dp;
}
int main()
{
	string name;
	cout<<"Input the file name. ";
	cin>>name;
	ifstream file1;
	file1.open("c.txt");
	if(file1.is_open())
	{
		while(!file1.eof())
		{
			file1>>K2;
		}
	}
	file1.close();
	
	ifstream file2;
	file2.open("w.txt");
	if(file2.is_open())
	{
		j2=0;
		while(!file2.eof())
		{
			file2>>w[j2];
			j2++;	
		}
	}
	file2.close();
	for(int ww=0;ww<j2;ww++)
	{
		cout<<w[ww]<<" ";
		N2++;
	}
	if(N2==31)
	{
		N2=N2-1;
	}
	else if(N2==1001)
	{
		N2=N2-1;
	}
	cout<<endl;
	ifstream file3;
	file3.open("p.txt");
	if(file3.is_open())
	{
		m=0;
		while(!file3.eof())
		{
			file3>>v[m];
			m++;
		}
	}
	file3.close();
	for(int pp=0;pp<m;pp++)
	{
		cout<<v[pp]<<" ";
	}	
	cout<<endl;
	cout<<N2<<" "<<K2<<endl;
	
	aa(N2,name,K2);
}
	/*
	aa(K,name,N);*/
